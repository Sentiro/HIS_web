# his_front

> his前端项目 基于vue.js
>
> 基本实现 挂号、诊断、开药、缴费、退号、发药共六个页面
>
> 由于部分需要请求后端的页面、响应跳转还未实现
>
> 可手动输入进行访问
>
> 挂号 /register
>
> 诊断、开药 /doctorMain
>
> 缴费 /pay
>
> 发药 /distribute
>
> 退号 /refundReg



